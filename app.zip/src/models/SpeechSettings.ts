export interface SpeechSettings {
  id: string;
  voice: string;
  speed: number;
}
